﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Main
{
    internal class product
    {
        public string item_cd { get; set; }
        public string item_no { get; set; }
        public string div_l { get; set; }
        public string div_m { get; set; }
        public string div_s { get; set; }
        public string div_n { get; set; }
        public string comp_nm { get; set; }
        public string img_prod_nm { get; set; }
        public string volume { get; set; }
        public string barcd { get; set; }
        public string width { get; set; }
        public string length { get; set; }
        public string nutrition_info { get; set; }
        public string position { get; set; }
        public int count { get; set; }
        public decimal purchase { get; set; }
        public decimal sale { get; set; }
    }
}
