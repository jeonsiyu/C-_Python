﻿namespace Netflix_Analyzer
{


    partial class Csharp_TeamDataSet
    {
    }
}
