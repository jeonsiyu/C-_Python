﻿namespace Main
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.button7 = new System.Windows.Forms.Button();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.button3 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.button2 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.label7ShowProductPriceNaver = new System.Windows.Forms.Label();
            this.SearchProductButton1 = new System.Windows.Forms.Button();
            this.textBox1SearchProduct = new System.Windows.Forms.TextBox();
            this.label1ProductName = new System.Windows.Forms.Label();
            this.pictureBox1ProductImage = new System.Windows.Forms.PictureBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.DataBase = new System.Windows.Forms.GroupBox();
            this.CountMyProductNum = new System.Windows.Forms.Label();
            this.CountMyProductTable = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.chart1MyProduct = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.buttonLarge = new System.Windows.Forms.Button();
            this.buttonSmall = new System.Windows.Forms.Button();
            this.buttonMiddle = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.comboBoxSmall = new System.Windows.Forms.ComboBox();
            this.comboBoxLarge = new System.Windows.Forms.ComboBox();
            this.labelSmall = new System.Windows.Forms.Label();
            this.labelLarge = new System.Windows.Forms.Label();
            this.labelMiddle = new System.Windows.Forms.Label();
            this.comboBoxMIddle = new System.Windows.Forms.ComboBox();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.position_Label = new System.Windows.Forms.Label();
            this.position_O = new System.Windows.Forms.Label();
            this.sale_Label = new System.Windows.Forms.Label();
            this.sale_T = new System.Windows.Forms.TextBox();
            this.sale = new System.Windows.Forms.Label();
            this.purchase_T = new System.Windows.Forms.TextBox();
            this.purchase_Label = new System.Windows.Forms.Label();
            this.count_T = new System.Windows.Forms.TextBox();
            this.purchase = new System.Windows.Forms.Label();
            this.sale_TT = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.purchase_TT = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.count_TT = new System.Windows.Forms.Label();
            this.Out = new System.Windows.Forms.Button();
            this.position_T = new System.Windows.Forms.TextBox();
            this.Barcd_F_T = new System.Windows.Forms.TextBox();
            this.button8 = new System.Windows.Forms.Button();
            this.Find = new System.Windows.Forms.Button();
            this.position = new System.Windows.Forms.Label();
            this.barcd_F = new System.Windows.Forms.Label();
            this.barcd_Label = new System.Windows.Forms.Label();
            this.div_n_Label = new System.Windows.Forms.Label();
            this.div_m_Label = new System.Windows.Forms.Label();
            this.img_prod_nm_Label = new System.Windows.Forms.Label();
            this.item_no_Label = new System.Windows.Forms.Label();
            this.nutrition_info_Label = new System.Windows.Forms.Label();
            this.volume_Label = new System.Windows.Forms.Label();
            this.comp_nm_Label = new System.Windows.Forms.Label();
            this.div_s_Label = new System.Windows.Forms.Label();
            this.div_l_Label = new System.Windows.Forms.Label();
            this.item_cd_Label = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.nutrition_info = new System.Windows.Forms.Label();
            this.volume = new System.Windows.Forms.Label();
            this.img_prod_nm = new System.Windows.Forms.Label();
            this.comp_nm = new System.Windows.Forms.Label();
            this.div_n = new System.Windows.Forms.Label();
            this.div_s = new System.Windows.Forms.Label();
            this.div_m = new System.Windows.Forms.Label();
            this.item_cd = new System.Windows.Forms.Label();
            this.div_l = new System.Windows.Forms.Label();
            this.item_no = new System.Windows.Forms.Label();
            this.List = new System.Windows.Forms.GroupBox();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.productBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.Timer = new System.Windows.Forms.Label();
            this.Time = new System.Windows.Forms.Label();
            this.Log = new System.Windows.Forms.ListBox();
            this.name = new System.Windows.Forms.TabControl();
            this.tapPage7 = new System.Windows.Forms.TabPage();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.delete = new System.Windows.Forms.Button();
            this.add = new System.Windows.Forms.Button();
            this.search = new System.Windows.Forms.Button();
            this.barcd = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.pay_label = new System.Windows.Forms.Label();
            this.count_label = new System.Windows.Forms.Label();
            this.item_label = new System.Windows.Forms.Label();
            this.pay = new System.Windows.Forms.Label();
            this.count = new System.Windows.Forms.Label();
            this.item = new System.Windows.Forms.Label();
            this.Timer1 = new System.Windows.Forms.Timer(this.components);
            this.itemcdDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.itemnoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.divlDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.divmDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.divsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.divnDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.compnmDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.imgprodnmDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.volumeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.barcdDV = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.widthDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lengthDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nutritioninfoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.positionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.countDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.purchaseDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.saleDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.productBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.barcodeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.itemDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.countDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.payDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.shoppingCartBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.shoppingCartBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tabPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.tabPage5.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1ProductImage)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.DataBase.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart1MyProduct)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.List.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productBindingSource)).BeginInit();
            this.name.SuspendLayout();
            this.tapPage7.SuspendLayout();
            this.groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.groupBox6.SuspendLayout();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.productBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.shoppingCartBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.shoppingCartBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.button7);
            this.tabPage6.Controls.Add(this.textBox8);
            this.tabPage6.Controls.Add(this.dataGridView2);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Margin = new System.Windows.Forms.Padding(1);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(1);
            this.tabPage6.Size = new System.Drawing.Size(1018, 668);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "상품 검색";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(730, 14);
            this.button7.Margin = new System.Windows.Forms.Padding(1);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(145, 43);
            this.button7.TabIndex = 5;
            this.button7.Text = "검색";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(217, 28);
            this.textBox8.Margin = new System.Windows.Forms.Padding(1);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(474, 21);
            this.textBox8.TabIndex = 4;
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(2, 85);
            this.dataGridView2.Margin = new System.Windows.Forms.Padding(1);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 102;
            this.dataGridView2.RowTemplate.Height = 44;
            this.dataGridView2.Size = new System.Drawing.Size(1012, 579);
            this.dataGridView2.TabIndex = 3;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.button3);
            this.tabPage5.Controls.Add(this.button5);
            this.tabPage5.Controls.Add(this.button6);
            this.tabPage5.Controls.Add(this.groupBox3);
            this.tabPage5.Controls.Add(this.groupBox4);
            this.tabPage5.Controls.Add(this.label7);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Margin = new System.Windows.Forms.Padding(1);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(1);
            this.tabPage5.Size = new System.Drawing.Size(1018, 668);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "QRcode스캔";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(144, 531);
            this.button3.Margin = new System.Windows.Forms.Padding(1);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(88, 24);
            this.button3.TabIndex = 11;
            this.button3.Text = "Quit";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(621, 531);
            this.button5.Margin = new System.Windows.Forms.Padding(1);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(77, 24);
            this.button5.TabIndex = 10;
            this.button5.Text = "탐색";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(759, 527);
            this.button6.Margin = new System.Windows.Forms.Padding(1);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(88, 28);
            this.button6.TabIndex = 9;
            this.button6.Text = "확인";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.textBox7);
            this.groupBox3.Location = new System.Drawing.Point(144, 382);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(1);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(1);
            this.groupBox3.Size = new System.Drawing.Size(704, 122);
            this.groupBox3.TabIndex = 8;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "내용";
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(23, 24);
            this.textBox7.Margin = new System.Windows.Forms.Padding(1);
            this.textBox7.Multiline = true;
            this.textBox7.Name = "textBox7";
            this.textBox7.ReadOnly = true;
            this.textBox7.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox7.Size = new System.Drawing.Size(666, 87);
            this.textBox7.TabIndex = 0;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.pictureBox2);
            this.groupBox4.Location = new System.Drawing.Point(144, 132);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(1);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(1);
            this.groupBox4.Size = new System.Drawing.Size(704, 240);
            this.groupBox4.TabIndex = 7;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "사진";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Location = new System.Drawing.Point(89, 40);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(501, 185);
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label7.Location = new System.Drawing.Point(372, 54);
            this.label7.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(254, 36);
            this.label7.TabIndex = 6;
            this.label7.Text = "QRCodeScanner";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.label6);
            this.tabPage4.Controls.Add(this.textBox6);
            this.tabPage4.Controls.Add(this.textBox5);
            this.tabPage4.Controls.Add(this.textBox4);
            this.tabPage4.Controls.Add(this.textBox3);
            this.tabPage4.Controls.Add(this.textBox2);
            this.tabPage4.Controls.Add(this.textBox1);
            this.tabPage4.Controls.Add(this.dataGridView1);
            this.tabPage4.Controls.Add(this.button2);
            this.tabPage4.Controls.Add(this.label5);
            this.tabPage4.Controls.Add(this.label4);
            this.tabPage4.Controls.Add(this.label3);
            this.tabPage4.Controls.Add(this.label2);
            this.tabPage4.Controls.Add(this.label1);
            this.tabPage4.Controls.Add(this.button1);
            this.tabPage4.Controls.Add(this.pictureBox1);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Margin = new System.Windows.Forms.Padding(1);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(1);
            this.tabPage4.Size = new System.Drawing.Size(1018, 668);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "QR코드 생성";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(33, 44);
            this.label6.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(41, 12);
            this.label6.TabIndex = 50;
            this.label6.Text = "바코드";
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(164, 42);
            this.textBox6.Margin = new System.Windows.Forms.Padding(1);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(129, 21);
            this.textBox6.TabIndex = 49;
            this.textBox6.TextChanged += new System.EventHandler(this.textBox6_TextChanged);
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(164, 280);
            this.textBox5.Margin = new System.Windows.Forms.Padding(1);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(129, 21);
            this.textBox5.TabIndex = 46;
            this.textBox5.TextChanged += new System.EventHandler(this.textBox5_TextChanged);
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(164, 227);
            this.textBox4.Margin = new System.Windows.Forms.Padding(1);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(129, 21);
            this.textBox4.TabIndex = 44;
            this.textBox4.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(164, 181);
            this.textBox3.Margin = new System.Windows.Forms.Padding(1);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(129, 21);
            this.textBox3.TabIndex = 42;
            this.textBox3.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(164, 134);
            this.textBox2.Margin = new System.Windows.Forms.Padding(1);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(129, 21);
            this.textBox2.TabIndex = 40;
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(164, 89);
            this.textBox1.Margin = new System.Windows.Forms.Padding(1);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(129, 21);
            this.textBox1.TabIndex = 36;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(318, 11);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(1);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 102;
            this.dataGridView1.RowTemplate.Height = 44;
            this.dataGridView1.Size = new System.Drawing.Size(696, 653);
            this.dataGridView1.TabIndex = 48;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(166, 332);
            this.button2.Margin = new System.Windows.Forms.Padding(1);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(127, 35);
            this.button2.TabIndex = 47;
            this.button2.Text = "저장";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(33, 280);
            this.label5.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(57, 12);
            this.label5.TabIndex = 45;
            this.label5.Text = "판매 가격";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(33, 227);
            this.label4.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 12);
            this.label4.TabIndex = 43;
            this.label4.Text = "제조 회사";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(33, 182);
            this.label3.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 12);
            this.label3.TabIndex = 41;
            this.label3.Text = "위치";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(33, 136);
            this.label2.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 12);
            this.label2.TabIndex = 39;
            this.label2.Text = "상품 분류(대)";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(33, 90);
            this.label1.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 12);
            this.label1.TabIndex = 38;
            this.label1.Text = "상품 이름";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(35, 332);
            this.button1.Margin = new System.Windows.Forms.Padding(1);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(127, 35);
            this.button1.TabIndex = 37;
            this.button1.Text = "생성";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(35, 384);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(258, 245);
            this.pictureBox1.TabIndex = 35;
            this.pictureBox1.TabStop = false;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.label7ShowProductPriceNaver);
            this.tabPage3.Controls.Add(this.SearchProductButton1);
            this.tabPage3.Controls.Add(this.textBox1SearchProduct);
            this.tabPage3.Controls.Add(this.label1ProductName);
            this.tabPage3.Controls.Add(this.pictureBox1ProductImage);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(2);
            this.tabPage3.Size = new System.Drawing.Size(1018, 668);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "최저가 검색";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // label7ShowProductPriceNaver
            // 
            this.label7ShowProductPriceNaver.AutoSize = true;
            this.label7ShowProductPriceNaver.Location = new System.Drawing.Point(239, 443);
            this.label7ShowProductPriceNaver.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7ShowProductPriceNaver.Name = "label7ShowProductPriceNaver";
            this.label7ShowProductPriceNaver.Size = new System.Drawing.Size(81, 12);
            this.label7ShowProductPriceNaver.TabIndex = 4;
            this.label7ShowProductPriceNaver.Text = "네이버 최저가";
            // 
            // SearchProductButton1
            // 
            this.SearchProductButton1.Location = new System.Drawing.Point(241, 522);
            this.SearchProductButton1.Margin = new System.Windows.Forms.Padding(2);
            this.SearchProductButton1.Name = "SearchProductButton1";
            this.SearchProductButton1.Size = new System.Drawing.Size(491, 85);
            this.SearchProductButton1.TabIndex = 3;
            this.SearchProductButton1.Text = "상품 검색";
            this.SearchProductButton1.UseVisualStyleBackColor = true;
            this.SearchProductButton1.Click += new System.EventHandler(this.SearchProductButton1_Click);
            // 
            // textBox1SearchProduct
            // 
            this.textBox1SearchProduct.Location = new System.Drawing.Point(241, 479);
            this.textBox1SearchProduct.Margin = new System.Windows.Forms.Padding(2);
            this.textBox1SearchProduct.Name = "textBox1SearchProduct";
            this.textBox1SearchProduct.Size = new System.Drawing.Size(491, 21);
            this.textBox1SearchProduct.TabIndex = 2;
            // 
            // label1ProductName
            // 
            this.label1ProductName.AutoSize = true;
            this.label1ProductName.Location = new System.Drawing.Point(239, 411);
            this.label1ProductName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1ProductName.Name = "label1ProductName";
            this.label1ProductName.Size = new System.Drawing.Size(41, 12);
            this.label1ProductName.TabIndex = 1;
            this.label1ProductName.Text = "상품명";
            // 
            // pictureBox1ProductImage
            // 
            this.pictureBox1ProductImage.Location = new System.Drawing.Point(241, 4);
            this.pictureBox1ProductImage.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1ProductImage.Name = "pictureBox1ProductImage";
            this.pictureBox1ProductImage.Size = new System.Drawing.Size(491, 387);
            this.pictureBox1ProductImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1ProductImage.TabIndex = 0;
            this.pictureBox1ProductImage.TabStop = false;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.DataBase);
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Controls.Add(this.groupBox1);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(2);
            this.tabPage2.Size = new System.Drawing.Size(1018, 668);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "통계";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // DataBase
            // 
            this.DataBase.Controls.Add(this.CountMyProductNum);
            this.DataBase.Controls.Add(this.CountMyProductTable);
            this.DataBase.Location = new System.Drawing.Point(11, 9);
            this.DataBase.Margin = new System.Windows.Forms.Padding(2);
            this.DataBase.Name = "DataBase";
            this.DataBase.Padding = new System.Windows.Forms.Padding(2);
            this.DataBase.Size = new System.Drawing.Size(200, 29);
            this.DataBase.TabIndex = 15;
            this.DataBase.TabStop = false;
            this.DataBase.Text = "DataBase";
            // 
            // CountMyProductNum
            // 
            this.CountMyProductNum.AutoSize = true;
            this.CountMyProductNum.Location = new System.Drawing.Point(48, 15);
            this.CountMyProductNum.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.CountMyProductNum.Name = "CountMyProductNum";
            this.CountMyProductNum.Size = new System.Drawing.Size(17, 12);
            this.CountMyProductNum.TabIndex = 11;
            this.CountMyProductNum.Text = "^^";
            // 
            // CountMyProductTable
            // 
            this.CountMyProductTable.AutoSize = true;
            this.CountMyProductTable.Location = new System.Drawing.Point(7, 15);
            this.CountMyProductTable.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.CountMyProductTable.Name = "CountMyProductTable";
            this.CountMyProductTable.Size = new System.Drawing.Size(29, 12);
            this.CountMyProductTable.TabIndex = 10;
            this.CountMyProductTable.Text = "개수";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.chart1MyProduct);
            this.groupBox2.Location = new System.Drawing.Point(10, 45);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox2.Size = new System.Drawing.Size(1006, 509);
            this.groupBox2.TabIndex = 14;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "차트 영역";
            // 
            // chart1MyProduct
            // 
            chartArea1.Name = "ChartArea1";
            this.chart1MyProduct.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.chart1MyProduct.Legends.Add(legend1);
            this.chart1MyProduct.Location = new System.Drawing.Point(4, 18);
            this.chart1MyProduct.Margin = new System.Windows.Forms.Padding(2);
            this.chart1MyProduct.Name = "chart1MyProduct";
            series1.ChartArea = "ChartArea1";
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            this.chart1MyProduct.Series.Add(series1);
            this.chart1MyProduct.Size = new System.Drawing.Size(998, 487);
            this.chart1MyProduct.TabIndex = 0;
            this.chart1MyProduct.Text = "chart1";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.buttonLarge);
            this.groupBox1.Controls.Add(this.buttonSmall);
            this.groupBox1.Controls.Add(this.buttonMiddle);
            this.groupBox1.Controls.Add(this.button4);
            this.groupBox1.Controls.Add(this.comboBoxSmall);
            this.groupBox1.Controls.Add(this.comboBoxLarge);
            this.groupBox1.Controls.Add(this.labelSmall);
            this.groupBox1.Controls.Add(this.labelLarge);
            this.groupBox1.Controls.Add(this.labelMiddle);
            this.groupBox1.Controls.Add(this.comboBoxMIddle);
            this.groupBox1.Location = new System.Drawing.Point(10, 558);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox1.Size = new System.Drawing.Size(299, 105);
            this.groupBox1.TabIndex = 13;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "필터";
            // 
            // buttonLarge
            // 
            this.buttonLarge.Location = new System.Drawing.Point(213, 23);
            this.buttonLarge.Margin = new System.Windows.Forms.Padding(2);
            this.buttonLarge.Name = "buttonLarge";
            this.buttonLarge.Size = new System.Drawing.Size(75, 17);
            this.buttonLarge.TabIndex = 11;
            this.buttonLarge.Text = "검색";
            this.buttonLarge.UseVisualStyleBackColor = true;
            this.buttonLarge.Click += new System.EventHandler(this.buttonLarge_Click);
            // 
            // buttonSmall
            // 
            this.buttonSmall.Location = new System.Drawing.Point(213, 83);
            this.buttonSmall.Margin = new System.Windows.Forms.Padding(2);
            this.buttonSmall.Name = "buttonSmall";
            this.buttonSmall.Size = new System.Drawing.Size(75, 17);
            this.buttonSmall.TabIndex = 10;
            this.buttonSmall.Text = "검색";
            this.buttonSmall.UseVisualStyleBackColor = true;
            this.buttonSmall.Click += new System.EventHandler(this.buttonSmall_Click);
            // 
            // buttonMiddle
            // 
            this.buttonMiddle.Location = new System.Drawing.Point(213, 53);
            this.buttonMiddle.Margin = new System.Windows.Forms.Padding(2);
            this.buttonMiddle.Name = "buttonMiddle";
            this.buttonMiddle.Size = new System.Drawing.Size(75, 17);
            this.buttonMiddle.TabIndex = 9;
            this.buttonMiddle.Text = "검색";
            this.buttonMiddle.UseVisualStyleBackColor = true;
            this.buttonMiddle.Click += new System.EventHandler(this.buttonMiddle_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(320, 35);
            this.button4.Margin = new System.Windows.Forms.Padding(2);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 17);
            this.button4.TabIndex = 8;
            this.button4.Text = "검색";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // comboBoxSmall
            // 
            this.comboBoxSmall.FormattingEnabled = true;
            this.comboBoxSmall.Location = new System.Drawing.Point(52, 83);
            this.comboBoxSmall.Margin = new System.Windows.Forms.Padding(2);
            this.comboBoxSmall.Name = "comboBoxSmall";
            this.comboBoxSmall.Size = new System.Drawing.Size(151, 20);
            this.comboBoxSmall.TabIndex = 7;
            // 
            // comboBoxLarge
            // 
            this.comboBoxLarge.FormattingEnabled = true;
            this.comboBoxLarge.Location = new System.Drawing.Point(52, 23);
            this.comboBoxLarge.Margin = new System.Windows.Forms.Padding(2);
            this.comboBoxLarge.Name = "comboBoxLarge";
            this.comboBoxLarge.Size = new System.Drawing.Size(151, 20);
            this.comboBoxLarge.TabIndex = 6;
            // 
            // labelSmall
            // 
            this.labelSmall.AutoSize = true;
            this.labelSmall.Location = new System.Drawing.Point(4, 85);
            this.labelSmall.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelSmall.Name = "labelSmall";
            this.labelSmall.Size = new System.Drawing.Size(41, 12);
            this.labelSmall.TabIndex = 5;
            this.labelSmall.Text = "소분류";
            // 
            // labelLarge
            // 
            this.labelLarge.AutoSize = true;
            this.labelLarge.Location = new System.Drawing.Point(4, 25);
            this.labelLarge.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelLarge.Name = "labelLarge";
            this.labelLarge.Size = new System.Drawing.Size(41, 12);
            this.labelLarge.TabIndex = 4;
            this.labelLarge.Text = "대분류";
            // 
            // labelMiddle
            // 
            this.labelMiddle.AutoSize = true;
            this.labelMiddle.Location = new System.Drawing.Point(4, 55);
            this.labelMiddle.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelMiddle.Name = "labelMiddle";
            this.labelMiddle.Size = new System.Drawing.Size(41, 12);
            this.labelMiddle.TabIndex = 3;
            this.labelMiddle.Text = "중분류";
            // 
            // comboBoxMIddle
            // 
            this.comboBoxMIddle.FormattingEnabled = true;
            this.comboBoxMIddle.Location = new System.Drawing.Point(52, 53);
            this.comboBoxMIddle.Margin = new System.Windows.Forms.Padding(2);
            this.comboBoxMIddle.Name = "comboBoxMIddle";
            this.comboBoxMIddle.Size = new System.Drawing.Size(151, 20);
            this.comboBoxMIddle.TabIndex = 2;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox8);
            this.tabPage1.Controls.Add(this.List);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(2);
            this.tabPage1.Size = new System.Drawing.Size(1018, 668);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "입고 및 출고";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.position_Label);
            this.groupBox8.Controls.Add(this.position_O);
            this.groupBox8.Controls.Add(this.sale_Label);
            this.groupBox8.Controls.Add(this.sale_T);
            this.groupBox8.Controls.Add(this.sale);
            this.groupBox8.Controls.Add(this.purchase_T);
            this.groupBox8.Controls.Add(this.purchase_Label);
            this.groupBox8.Controls.Add(this.count_T);
            this.groupBox8.Controls.Add(this.purchase);
            this.groupBox8.Controls.Add(this.sale_TT);
            this.groupBox8.Controls.Add(this.label9);
            this.groupBox8.Controls.Add(this.purchase_TT);
            this.groupBox8.Controls.Add(this.label10);
            this.groupBox8.Controls.Add(this.count_TT);
            this.groupBox8.Controls.Add(this.Out);
            this.groupBox8.Controls.Add(this.position_T);
            this.groupBox8.Controls.Add(this.Barcd_F_T);
            this.groupBox8.Controls.Add(this.button8);
            this.groupBox8.Controls.Add(this.Find);
            this.groupBox8.Controls.Add(this.position);
            this.groupBox8.Controls.Add(this.barcd_F);
            this.groupBox8.Controls.Add(this.barcd_Label);
            this.groupBox8.Controls.Add(this.div_n_Label);
            this.groupBox8.Controls.Add(this.div_m_Label);
            this.groupBox8.Controls.Add(this.img_prod_nm_Label);
            this.groupBox8.Controls.Add(this.item_no_Label);
            this.groupBox8.Controls.Add(this.nutrition_info_Label);
            this.groupBox8.Controls.Add(this.volume_Label);
            this.groupBox8.Controls.Add(this.comp_nm_Label);
            this.groupBox8.Controls.Add(this.div_s_Label);
            this.groupBox8.Controls.Add(this.div_l_Label);
            this.groupBox8.Controls.Add(this.item_cd_Label);
            this.groupBox8.Controls.Add(this.label11);
            this.groupBox8.Controls.Add(this.nutrition_info);
            this.groupBox8.Controls.Add(this.volume);
            this.groupBox8.Controls.Add(this.img_prod_nm);
            this.groupBox8.Controls.Add(this.comp_nm);
            this.groupBox8.Controls.Add(this.div_n);
            this.groupBox8.Controls.Add(this.div_s);
            this.groupBox8.Controls.Add(this.div_m);
            this.groupBox8.Controls.Add(this.item_cd);
            this.groupBox8.Controls.Add(this.div_l);
            this.groupBox8.Controls.Add(this.item_no);
            this.groupBox8.Location = new System.Drawing.Point(8, 5);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(1002, 275);
            this.groupBox8.TabIndex = 7;
            this.groupBox8.TabStop = false;
            // 
            // position_Label
            // 
            this.position_Label.AutoSize = true;
            this.position_Label.Location = new System.Drawing.Point(591, 29);
            this.position_Label.Name = "position_Label";
            this.position_Label.Size = new System.Drawing.Size(49, 12);
            this.position_Label.TabIndex = 51;
            this.position_Label.Text = "position";
            // 
            // position_O
            // 
            this.position_O.AutoSize = true;
            this.position_O.Location = new System.Drawing.Point(508, 29);
            this.position_O.Name = "position_O";
            this.position_O.Size = new System.Drawing.Size(29, 12);
            this.position_O.TabIndex = 50;
            this.position_O.Text = "위치";
            // 
            // sale_Label
            // 
            this.sale_Label.AutoSize = true;
            this.sale_Label.Location = new System.Drawing.Point(591, 143);
            this.sale_Label.Name = "sale_Label";
            this.sale_Label.Size = new System.Drawing.Size(29, 12);
            this.sale_Label.TabIndex = 49;
            this.sale_Label.Text = "sale";
            // 
            // sale_T
            // 
            this.sale_T.Location = new System.Drawing.Point(761, 174);
            this.sale_T.Name = "sale_T";
            this.sale_T.Size = new System.Drawing.Size(113, 21);
            this.sale_T.TabIndex = 37;
            // 
            // sale
            // 
            this.sale.AutoSize = true;
            this.sale.Location = new System.Drawing.Point(508, 143);
            this.sale.Name = "sale";
            this.sale.Size = new System.Drawing.Size(53, 12);
            this.sale.TabIndex = 48;
            this.sale.Text = "판매가격";
            // 
            // purchase_T
            // 
            this.purchase_T.Location = new System.Drawing.Point(761, 137);
            this.purchase_T.Name = "purchase_T";
            this.purchase_T.Size = new System.Drawing.Size(113, 21);
            this.purchase_T.TabIndex = 36;
            // 
            // purchase_Label
            // 
            this.purchase_Label.AutoSize = true;
            this.purchase_Label.Location = new System.Drawing.Point(591, 105);
            this.purchase_Label.Name = "purchase_Label";
            this.purchase_Label.Size = new System.Drawing.Size(58, 12);
            this.purchase_Label.TabIndex = 47;
            this.purchase_Label.Text = "purchase";
            // 
            // count_T
            // 
            this.count_T.Location = new System.Drawing.Point(761, 100);
            this.count_T.Name = "count_T";
            this.count_T.Size = new System.Drawing.Size(113, 21);
            this.count_T.TabIndex = 35;
            // 
            // purchase
            // 
            this.purchase.AutoSize = true;
            this.purchase.Location = new System.Drawing.Point(508, 105);
            this.purchase.Name = "purchase";
            this.purchase.Size = new System.Drawing.Size(53, 12);
            this.purchase.TabIndex = 46;
            this.purchase.Text = "구입가격";
            // 
            // sale_TT
            // 
            this.sale_TT.AutoSize = true;
            this.sale_TT.Location = new System.Drawing.Point(684, 177);
            this.sale_TT.Name = "sale_TT";
            this.sale_TT.Size = new System.Drawing.Size(53, 12);
            this.sale_TT.TabIndex = 34;
            this.sale_TT.Text = "판매가격";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(591, 67);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(36, 12);
            this.label9.TabIndex = 45;
            this.label9.Text = "count";
            // 
            // purchase_TT
            // 
            this.purchase_TT.AutoSize = true;
            this.purchase_TT.Location = new System.Drawing.Point(684, 141);
            this.purchase_TT.Name = "purchase_TT";
            this.purchase_TT.Size = new System.Drawing.Size(53, 12);
            this.purchase_TT.TabIndex = 33;
            this.purchase_TT.Text = "구입가격";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(508, 67);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(29, 12);
            this.label10.TabIndex = 44;
            this.label10.Text = "개수";
            // 
            // count_TT
            // 
            this.count_TT.AutoSize = true;
            this.count_TT.Location = new System.Drawing.Point(684, 105);
            this.count_TT.Name = "count_TT";
            this.count_TT.Size = new System.Drawing.Size(29, 12);
            this.count_TT.TabIndex = 32;
            this.count_TT.Text = "개수";
            // 
            // Out
            // 
            this.Out.Location = new System.Drawing.Point(890, 151);
            this.Out.Name = "Out";
            this.Out.Size = new System.Drawing.Size(94, 55);
            this.Out.TabIndex = 31;
            this.Out.Text = "OUT";
            this.Out.UseVisualStyleBackColor = true;
            this.Out.Click += new System.EventHandler(this.Out_Click);
            // 
            // position_T
            // 
            this.position_T.Location = new System.Drawing.Point(761, 63);
            this.position_T.Name = "position_T";
            this.position_T.Size = new System.Drawing.Size(113, 21);
            this.position_T.TabIndex = 30;
            // 
            // Barcd_F_T
            // 
            this.Barcd_F_T.Location = new System.Drawing.Point(761, 26);
            this.Barcd_F_T.Name = "Barcd_F_T";
            this.Barcd_F_T.Size = new System.Drawing.Size(113, 21);
            this.Barcd_F_T.TabIndex = 29;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(890, 85);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(94, 55);
            this.button8.TabIndex = 27;
            this.button8.Text = "ADD";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.Add_Click);
            // 
            // Find
            // 
            this.Find.Location = new System.Drawing.Point(890, 20);
            this.Find.Name = "Find";
            this.Find.Size = new System.Drawing.Size(96, 55);
            this.Find.TabIndex = 26;
            this.Find.Text = "조회";
            this.Find.UseVisualStyleBackColor = true;
            this.Find.Click += new System.EventHandler(this.Find_Click);
            // 
            // position
            // 
            this.position.AutoSize = true;
            this.position.Location = new System.Drawing.Point(684, 69);
            this.position.Name = "position";
            this.position.Size = new System.Drawing.Size(29, 12);
            this.position.TabIndex = 24;
            this.position.Text = "위치";
            // 
            // barcd_F
            // 
            this.barcd_F.AutoSize = true;
            this.barcd_F.Location = new System.Drawing.Point(684, 33);
            this.barcd_F.Name = "barcd_F";
            this.barcd_F.Size = new System.Drawing.Size(69, 12);
            this.barcd_F.TabIndex = 22;
            this.barcd_F.Text = "바코드 검색";
            // 
            // barcd_Label
            // 
            this.barcd_Label.AutoSize = true;
            this.barcd_Label.Location = new System.Drawing.Point(353, 139);
            this.barcd_Label.Name = "barcd_Label";
            this.barcd_Label.Size = new System.Drawing.Size(37, 12);
            this.barcd_Label.TabIndex = 21;
            this.barcd_Label.Text = "barcd";
            // 
            // div_n_Label
            // 
            this.div_n_Label.AutoSize = true;
            this.div_n_Label.Location = new System.Drawing.Point(353, 102);
            this.div_n_Label.Name = "div_n_Label";
            this.div_n_Label.Size = new System.Drawing.Size(34, 12);
            this.div_n_Label.TabIndex = 20;
            this.div_n_Label.Text = "div_n";
            // 
            // div_m_Label
            // 
            this.div_m_Label.AutoSize = true;
            this.div_m_Label.Location = new System.Drawing.Point(353, 65);
            this.div_m_Label.Name = "div_m_Label";
            this.div_m_Label.Size = new System.Drawing.Size(38, 12);
            this.div_m_Label.TabIndex = 19;
            this.div_m_Label.Text = "div_m";
            // 
            // img_prod_nm_Label
            // 
            this.img_prod_nm_Label.AutoSize = true;
            this.img_prod_nm_Label.Location = new System.Drawing.Point(353, 176);
            this.img_prod_nm_Label.Name = "img_prod_nm_Label";
            this.img_prod_nm_Label.Size = new System.Drawing.Size(81, 12);
            this.img_prod_nm_Label.TabIndex = 18;
            this.img_prod_nm_Label.Text = "img_prod_nm";
            // 
            // item_no_Label
            // 
            this.item_no_Label.AutoSize = true;
            this.item_no_Label.Location = new System.Drawing.Point(353, 28);
            this.item_no_Label.Name = "item_no_Label";
            this.item_no_Label.Size = new System.Drawing.Size(49, 12);
            this.item_no_Label.TabIndex = 17;
            this.item_no_Label.Text = "item_no";
            // 
            // nutrition_info_Label
            // 
            this.nutrition_info_Label.AutoSize = true;
            this.nutrition_info_Label.Location = new System.Drawing.Point(105, 217);
            this.nutrition_info_Label.Name = "nutrition_info_Label";
            this.nutrition_info_Label.Size = new System.Drawing.Size(75, 12);
            this.nutrition_info_Label.TabIndex = 16;
            this.nutrition_info_Label.Text = "nutrition_info";
            // 
            // volume_Label
            // 
            this.volume_Label.AutoSize = true;
            this.volume_Label.Location = new System.Drawing.Point(105, 179);
            this.volume_Label.Name = "volume_Label";
            this.volume_Label.Size = new System.Drawing.Size(46, 12);
            this.volume_Label.TabIndex = 15;
            this.volume_Label.Text = "volume";
            // 
            // comp_nm_Label
            // 
            this.comp_nm_Label.AutoSize = true;
            this.comp_nm_Label.Location = new System.Drawing.Point(105, 139);
            this.comp_nm_Label.Name = "comp_nm_Label";
            this.comp_nm_Label.Size = new System.Drawing.Size(61, 12);
            this.comp_nm_Label.TabIndex = 14;
            this.comp_nm_Label.Text = "comp_nm";
            // 
            // div_s_Label
            // 
            this.div_s_Label.AutoSize = true;
            this.div_s_Label.Location = new System.Drawing.Point(105, 102);
            this.div_s_Label.Name = "div_s_Label";
            this.div_s_Label.Size = new System.Drawing.Size(34, 12);
            this.div_s_Label.TabIndex = 13;
            this.div_s_Label.Text = "div_s";
            // 
            // div_l_Label
            // 
            this.div_l_Label.AutoSize = true;
            this.div_l_Label.Location = new System.Drawing.Point(105, 65);
            this.div_l_Label.Name = "div_l_Label";
            this.div_l_Label.Size = new System.Drawing.Size(30, 12);
            this.div_l_Label.TabIndex = 12;
            this.div_l_Label.Text = "div_l";
            // 
            // item_cd_Label
            // 
            this.item_cd_Label.AutoSize = true;
            this.item_cd_Label.Location = new System.Drawing.Point(105, 28);
            this.item_cd_Label.Name = "item_cd_Label";
            this.item_cd_Label.Size = new System.Drawing.Size(49, 12);
            this.item_cd_Label.TabIndex = 11;
            this.item_cd_Label.Text = "item_cd";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(255, 139);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(41, 12);
            this.label11.TabIndex = 10;
            this.label11.Text = "바코드";
            // 
            // nutrition_info
            // 
            this.nutrition_info.AutoSize = true;
            this.nutrition_info.Location = new System.Drawing.Point(16, 218);
            this.nutrition_info.Name = "nutrition_info";
            this.nutrition_info.Size = new System.Drawing.Size(41, 12);
            this.nutrition_info.TabIndex = 9;
            this.nutrition_info.Text = "영양소";
            // 
            // volume
            // 
            this.volume.AutoSize = true;
            this.volume.Location = new System.Drawing.Point(16, 180);
            this.volume.Name = "volume";
            this.volume.Size = new System.Drawing.Size(29, 12);
            this.volume.TabIndex = 8;
            this.volume.Text = "무게";
            // 
            // img_prod_nm
            // 
            this.img_prod_nm.AutoSize = true;
            this.img_prod_nm.Location = new System.Drawing.Point(255, 176);
            this.img_prod_nm.Name = "img_prod_nm";
            this.img_prod_nm.Size = new System.Drawing.Size(41, 12);
            this.img_prod_nm.TabIndex = 7;
            this.img_prod_nm.Text = "상풍명";
            // 
            // comp_nm
            // 
            this.comp_nm.AutoSize = true;
            this.comp_nm.Location = new System.Drawing.Point(16, 142);
            this.comp_nm.Name = "comp_nm";
            this.comp_nm.Size = new System.Drawing.Size(41, 12);
            this.comp_nm.TabIndex = 6;
            this.comp_nm.Text = "제작사";
            // 
            // div_n
            // 
            this.div_n.AutoSize = true;
            this.div_n.Location = new System.Drawing.Point(255, 102);
            this.div_n.Name = "div_n";
            this.div_n.Size = new System.Drawing.Size(41, 12);
            this.div_n.TabIndex = 5;
            this.div_n.Text = "세분류";
            // 
            // div_s
            // 
            this.div_s.AutoSize = true;
            this.div_s.Location = new System.Drawing.Point(16, 104);
            this.div_s.Name = "div_s";
            this.div_s.Size = new System.Drawing.Size(41, 12);
            this.div_s.TabIndex = 4;
            this.div_s.Text = "소분류";
            // 
            // div_m
            // 
            this.div_m.AutoSize = true;
            this.div_m.Location = new System.Drawing.Point(255, 65);
            this.div_m.Name = "div_m";
            this.div_m.Size = new System.Drawing.Size(41, 12);
            this.div_m.TabIndex = 3;
            this.div_m.Text = "중분류";
            // 
            // item_cd
            // 
            this.item_cd.AutoSize = true;
            this.item_cd.Location = new System.Drawing.Point(16, 28);
            this.item_cd.Name = "item_cd";
            this.item_cd.Size = new System.Drawing.Size(65, 12);
            this.item_cd.TabIndex = 0;
            this.item_cd.Text = "아이템코드";
            // 
            // div_l
            // 
            this.div_l.AutoSize = true;
            this.div_l.Location = new System.Drawing.Point(16, 66);
            this.div_l.Name = "div_l";
            this.div_l.Size = new System.Drawing.Size(41, 12);
            this.div_l.TabIndex = 2;
            this.div_l.Text = "대분류";
            // 
            // item_no
            // 
            this.item_no.AutoSize = true;
            this.item_no.Location = new System.Drawing.Point(255, 28);
            this.item_no.Name = "item_no";
            this.item_no.Size = new System.Drawing.Size(65, 12);
            this.item_no.TabIndex = 1;
            this.item_no.Text = "아이템넘버";
            // 
            // List
            // 
            this.List.Controls.Add(this.dataGridView4);
            this.List.Controls.Add(this.Timer);
            this.List.Controls.Add(this.Time);
            this.List.Controls.Add(this.Log);
            this.List.Location = new System.Drawing.Point(8, 285);
            this.List.Name = "List";
            this.List.Size = new System.Drawing.Size(1002, 378);
            this.List.TabIndex = 8;
            this.List.TabStop = false;
            // 
            // dataGridView4
            // 
            this.dataGridView4.AutoGenerateColumns = false;
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.itemcdDataGridViewTextBoxColumn,
            this.itemnoDataGridViewTextBoxColumn,
            this.divlDataGridViewTextBoxColumn,
            this.divmDataGridViewTextBoxColumn,
            this.divsDataGridViewTextBoxColumn,
            this.divnDataGridViewTextBoxColumn,
            this.compnmDataGridViewTextBoxColumn,
            this.imgprodnmDataGridViewTextBoxColumn,
            this.volumeDataGridViewTextBoxColumn,
            this.barcdDV,
            this.widthDataGridViewTextBoxColumn,
            this.lengthDataGridViewTextBoxColumn,
            this.nutritioninfoDataGridViewTextBoxColumn,
            this.positionDataGridViewTextBoxColumn,
            this.countDataGridViewTextBoxColumn1,
            this.purchaseDataGridViewTextBoxColumn,
            this.saleDataGridViewTextBoxColumn});
            this.dataGridView4.DataSource = this.productBindingSource1;
            this.dataGridView4.Location = new System.Drawing.Point(0, 7);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.RowTemplate.Height = 23;
            this.dataGridView4.Size = new System.Drawing.Size(1002, 253);
            this.dataGridView4.TabIndex = 4;
            this.dataGridView4.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView4_CellContentClick);
            this.dataGridView4.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.DataGridView1_CellFormatting);
            // 
            // Timer
            // 
            this.Timer.AutoSize = true;
            this.Timer.Location = new System.Drawing.Point(1, 360);
            this.Timer.Name = "Timer";
            this.Timer.Size = new System.Drawing.Size(38, 12);
            this.Timer.TabIndex = 3;
            this.Timer.Text = "Timer";
            // 
            // Time
            // 
            this.Time.AutoSize = true;
            this.Time.Location = new System.Drawing.Point(0, 360);
            this.Time.Name = "Time";
            this.Time.Size = new System.Drawing.Size(0, 12);
            this.Time.TabIndex = 2;
            // 
            // Log
            // 
            this.Log.FormattingEnabled = true;
            this.Log.ItemHeight = 12;
            this.Log.Location = new System.Drawing.Point(0, 266);
            this.Log.Name = "Log";
            this.Log.Size = new System.Drawing.Size(1002, 88);
            this.Log.TabIndex = 1;
            // 
            // name
            // 
            this.name.Controls.Add(this.tabPage1);
            this.name.Controls.Add(this.tabPage2);
            this.name.Controls.Add(this.tabPage3);
            this.name.Controls.Add(this.tabPage4);
            this.name.Controls.Add(this.tabPage5);
            this.name.Controls.Add(this.tabPage6);
            this.name.Controls.Add(this.tapPage7);
            this.name.Location = new System.Drawing.Point(0, 0);
            this.name.Margin = new System.Windows.Forms.Padding(2);
            this.name.Name = "name";
            this.name.SelectedIndex = 0;
            this.name.Size = new System.Drawing.Size(1026, 694);
            this.name.TabIndex = 0;
            // 
            // tapPage7
            // 
            this.tapPage7.Controls.Add(this.groupBox7);
            this.tapPage7.Controls.Add(this.groupBox6);
            this.tapPage7.Controls.Add(this.groupBox5);
            this.tapPage7.Location = new System.Drawing.Point(4, 22);
            this.tapPage7.Name = "tapPage7";
            this.tapPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tapPage7.Size = new System.Drawing.Size(1018, 668);
            this.tapPage7.TabIndex = 6;
            this.tapPage7.Text = "구매";
            this.tapPage7.UseVisualStyleBackColor = true;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.dataGridView3);
            this.groupBox7.Location = new System.Drawing.Point(8, 175);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(1004, 487);
            this.groupBox7.TabIndex = 1;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "장바구니";
            // 
            // dataGridView3
            // 
            this.dataGridView3.AutoGenerateColumns = false;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.barcodeDataGridViewTextBoxColumn,
            this.itemDataGridViewTextBoxColumn,
            this.countDataGridViewTextBoxColumn,
            this.payDataGridViewTextBoxColumn});
            this.dataGridView3.DataSource = this.shoppingCartBindingSource1;
            this.dataGridView3.Location = new System.Drawing.Point(6, 20);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.RowHeadersWidth = 102;
            this.dataGridView3.RowTemplate.Height = 23;
            this.dataGridView3.Size = new System.Drawing.Size(998, 461);
            this.dataGridView3.TabIndex = 0;
            this.dataGridView3.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView3_CellContentClick);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.delete);
            this.groupBox6.Controls.Add(this.add);
            this.groupBox6.Controls.Add(this.search);
            this.groupBox6.Controls.Add(this.barcd);
            this.groupBox6.Controls.Add(this.label8);
            this.groupBox6.Location = new System.Drawing.Point(531, 6);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(481, 163);
            this.groupBox6.TabIndex = 1;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "조회/추가/삭제";
            // 
            // delete
            // 
            this.delete.Location = new System.Drawing.Point(400, 101);
            this.delete.Name = "delete";
            this.delete.Size = new System.Drawing.Size(75, 23);
            this.delete.TabIndex = 10;
            this.delete.Text = "삭제";
            this.delete.UseVisualStyleBackColor = true;
            this.delete.Click += new System.EventHandler(this.delete_Click);
            // 
            // add
            // 
            this.add.Location = new System.Drawing.Point(400, 65);
            this.add.Name = "add";
            this.add.Size = new System.Drawing.Size(75, 23);
            this.add.TabIndex = 9;
            this.add.Text = "추가";
            this.add.UseVisualStyleBackColor = true;
            this.add.Click += new System.EventHandler(this.add_Click);
            // 
            // search
            // 
            this.search.Location = new System.Drawing.Point(400, 29);
            this.search.Name = "search";
            this.search.Size = new System.Drawing.Size(75, 23);
            this.search.TabIndex = 8;
            this.search.Text = "조회";
            this.search.UseVisualStyleBackColor = true;
            this.search.Click += new System.EventHandler(this.search_Click);
            // 
            // barcd
            // 
            this.barcd.Location = new System.Drawing.Point(104, 65);
            this.barcd.Name = "barcd";
            this.barcd.Size = new System.Drawing.Size(266, 21);
            this.barcd.TabIndex = 7;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(33, 70);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(65, 12);
            this.label8.TabIndex = 6;
            this.label8.Text = "바코드입력";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.pay_label);
            this.groupBox5.Controls.Add(this.count_label);
            this.groupBox5.Controls.Add(this.item_label);
            this.groupBox5.Controls.Add(this.pay);
            this.groupBox5.Controls.Add(this.count);
            this.groupBox5.Controls.Add(this.item);
            this.groupBox5.Location = new System.Drawing.Point(8, 6);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(397, 163);
            this.groupBox5.TabIndex = 0;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "재고현황";
            // 
            // pay_label
            // 
            this.pay_label.AutoSize = true;
            this.pay_label.Location = new System.Drawing.Point(115, 106);
            this.pay_label.Name = "pay_label";
            this.pay_label.Size = new System.Drawing.Size(59, 12);
            this.pay_label.TabIndex = 5;
            this.pay_label.Text = "pay_label";
            // 
            // count_label
            // 
            this.count_label.AutoSize = true;
            this.count_label.Location = new System.Drawing.Point(115, 70);
            this.count_label.Name = "count_label";
            this.count_label.Size = new System.Drawing.Size(69, 12);
            this.count_label.TabIndex = 4;
            this.count_label.Text = "count_label";
            // 
            // item_label
            // 
            this.item_label.AutoSize = true;
            this.item_label.Location = new System.Drawing.Point(115, 34);
            this.item_label.Name = "item_label";
            this.item_label.Size = new System.Drawing.Size(62, 12);
            this.item_label.TabIndex = 3;
            this.item_label.Text = "item_label";
            // 
            // pay
            // 
            this.pay.AutoSize = true;
            this.pay.Location = new System.Drawing.Point(42, 106);
            this.pay.Name = "pay";
            this.pay.Size = new System.Drawing.Size(29, 12);
            this.pay.TabIndex = 2;
            this.pay.Text = "금액";
            // 
            // count
            // 
            this.count.AutoSize = true;
            this.count.Location = new System.Drawing.Point(42, 70);
            this.count.Name = "count";
            this.count.Size = new System.Drawing.Size(29, 12);
            this.count.TabIndex = 1;
            this.count.Text = "개수";
            // 
            // item
            // 
            this.item.AutoSize = true;
            this.item.Location = new System.Drawing.Point(42, 34);
            this.item.Name = "item";
            this.item.Size = new System.Drawing.Size(41, 12);
            this.item.TabIndex = 0;
            this.item.Text = "상품명";
            // 
            // Timer1
            // 
            this.Timer1.Enabled = true;
            this.Timer1.Interval = 1000;
            this.Timer1.Tick += new System.EventHandler(this.Timer1_Tick);
            // 
            // itemcdDataGridViewTextBoxColumn
            // 
            this.itemcdDataGridViewTextBoxColumn.DataPropertyName = "item_cd";
            this.itemcdDataGridViewTextBoxColumn.HeaderText = "item_cd";
            this.itemcdDataGridViewTextBoxColumn.Name = "itemcdDataGridViewTextBoxColumn";
            // 
            // itemnoDataGridViewTextBoxColumn
            // 
            this.itemnoDataGridViewTextBoxColumn.DataPropertyName = "item_no";
            this.itemnoDataGridViewTextBoxColumn.HeaderText = "item_no";
            this.itemnoDataGridViewTextBoxColumn.Name = "itemnoDataGridViewTextBoxColumn";
            // 
            // divlDataGridViewTextBoxColumn
            // 
            this.divlDataGridViewTextBoxColumn.DataPropertyName = "div_l";
            this.divlDataGridViewTextBoxColumn.HeaderText = "div_l";
            this.divlDataGridViewTextBoxColumn.Name = "divlDataGridViewTextBoxColumn";
            // 
            // divmDataGridViewTextBoxColumn
            // 
            this.divmDataGridViewTextBoxColumn.DataPropertyName = "div_m";
            this.divmDataGridViewTextBoxColumn.HeaderText = "div_m";
            this.divmDataGridViewTextBoxColumn.Name = "divmDataGridViewTextBoxColumn";
            // 
            // divsDataGridViewTextBoxColumn
            // 
            this.divsDataGridViewTextBoxColumn.DataPropertyName = "div_s";
            this.divsDataGridViewTextBoxColumn.HeaderText = "div_s";
            this.divsDataGridViewTextBoxColumn.Name = "divsDataGridViewTextBoxColumn";
            // 
            // divnDataGridViewTextBoxColumn
            // 
            this.divnDataGridViewTextBoxColumn.DataPropertyName = "div_n";
            this.divnDataGridViewTextBoxColumn.HeaderText = "div_n";
            this.divnDataGridViewTextBoxColumn.Name = "divnDataGridViewTextBoxColumn";
            // 
            // compnmDataGridViewTextBoxColumn
            // 
            this.compnmDataGridViewTextBoxColumn.DataPropertyName = "comp_nm";
            this.compnmDataGridViewTextBoxColumn.HeaderText = "comp_nm";
            this.compnmDataGridViewTextBoxColumn.Name = "compnmDataGridViewTextBoxColumn";
            // 
            // imgprodnmDataGridViewTextBoxColumn
            // 
            this.imgprodnmDataGridViewTextBoxColumn.DataPropertyName = "img_prod_nm";
            this.imgprodnmDataGridViewTextBoxColumn.HeaderText = "img_prod_nm";
            this.imgprodnmDataGridViewTextBoxColumn.Name = "imgprodnmDataGridViewTextBoxColumn";
            // 
            // volumeDataGridViewTextBoxColumn
            // 
            this.volumeDataGridViewTextBoxColumn.DataPropertyName = "volume";
            this.volumeDataGridViewTextBoxColumn.HeaderText = "volume";
            this.volumeDataGridViewTextBoxColumn.Name = "volumeDataGridViewTextBoxColumn";
            // 
            // barcdDV
            // 
            this.barcdDV.DataPropertyName = "barcd";
            this.barcdDV.HeaderText = "barcd";
            this.barcdDV.Name = "barcdDV";
            // 
            // widthDataGridViewTextBoxColumn
            // 
            this.widthDataGridViewTextBoxColumn.DataPropertyName = "width";
            this.widthDataGridViewTextBoxColumn.HeaderText = "width";
            this.widthDataGridViewTextBoxColumn.Name = "widthDataGridViewTextBoxColumn";
            // 
            // lengthDataGridViewTextBoxColumn
            // 
            this.lengthDataGridViewTextBoxColumn.DataPropertyName = "length";
            this.lengthDataGridViewTextBoxColumn.HeaderText = "length";
            this.lengthDataGridViewTextBoxColumn.Name = "lengthDataGridViewTextBoxColumn";
            // 
            // nutritioninfoDataGridViewTextBoxColumn
            // 
            this.nutritioninfoDataGridViewTextBoxColumn.DataPropertyName = "nutrition_info";
            this.nutritioninfoDataGridViewTextBoxColumn.HeaderText = "nutrition_info";
            this.nutritioninfoDataGridViewTextBoxColumn.Name = "nutritioninfoDataGridViewTextBoxColumn";
            // 
            // positionDataGridViewTextBoxColumn
            // 
            this.positionDataGridViewTextBoxColumn.DataPropertyName = "position";
            this.positionDataGridViewTextBoxColumn.HeaderText = "position";
            this.positionDataGridViewTextBoxColumn.Name = "positionDataGridViewTextBoxColumn";
            // 
            // countDataGridViewTextBoxColumn1
            // 
            this.countDataGridViewTextBoxColumn1.DataPropertyName = "count";
            this.countDataGridViewTextBoxColumn1.HeaderText = "count";
            this.countDataGridViewTextBoxColumn1.Name = "countDataGridViewTextBoxColumn1";
            // 
            // purchaseDataGridViewTextBoxColumn
            // 
            this.purchaseDataGridViewTextBoxColumn.DataPropertyName = "purchase";
            this.purchaseDataGridViewTextBoxColumn.HeaderText = "purchase";
            this.purchaseDataGridViewTextBoxColumn.Name = "purchaseDataGridViewTextBoxColumn";
            // 
            // saleDataGridViewTextBoxColumn
            // 
            this.saleDataGridViewTextBoxColumn.DataPropertyName = "sale";
            this.saleDataGridViewTextBoxColumn.HeaderText = "sale";
            this.saleDataGridViewTextBoxColumn.Name = "saleDataGridViewTextBoxColumn";
            // 
            // productBindingSource1
            // 
            this.productBindingSource1.DataSource = typeof(Main.product);
            // 
            // barcodeDataGridViewTextBoxColumn
            // 
            this.barcodeDataGridViewTextBoxColumn.DataPropertyName = "barcode";
            this.barcodeDataGridViewTextBoxColumn.HeaderText = "barcode";
            this.barcodeDataGridViewTextBoxColumn.MinimumWidth = 12;
            this.barcodeDataGridViewTextBoxColumn.Name = "barcodeDataGridViewTextBoxColumn";
            this.barcodeDataGridViewTextBoxColumn.Width = 250;
            // 
            // itemDataGridViewTextBoxColumn
            // 
            this.itemDataGridViewTextBoxColumn.DataPropertyName = "item";
            this.itemDataGridViewTextBoxColumn.HeaderText = "item";
            this.itemDataGridViewTextBoxColumn.MinimumWidth = 12;
            this.itemDataGridViewTextBoxColumn.Name = "itemDataGridViewTextBoxColumn";
            this.itemDataGridViewTextBoxColumn.Width = 250;
            // 
            // countDataGridViewTextBoxColumn
            // 
            this.countDataGridViewTextBoxColumn.DataPropertyName = "count";
            this.countDataGridViewTextBoxColumn.HeaderText = "count";
            this.countDataGridViewTextBoxColumn.MinimumWidth = 12;
            this.countDataGridViewTextBoxColumn.Name = "countDataGridViewTextBoxColumn";
            this.countDataGridViewTextBoxColumn.Width = 250;
            // 
            // payDataGridViewTextBoxColumn
            // 
            this.payDataGridViewTextBoxColumn.DataPropertyName = "pay";
            this.payDataGridViewTextBoxColumn.HeaderText = "pay";
            this.payDataGridViewTextBoxColumn.MinimumWidth = 12;
            this.payDataGridViewTextBoxColumn.Name = "payDataGridViewTextBoxColumn";
            this.payDataGridViewTextBoxColumn.Width = 250;
            // 
            // shoppingCartBindingSource1
            // 
            this.shoppingCartBindingSource1.DataSource = typeof(Main.ShoppingCart);
            // 
            // shoppingCartBindingSource
            // 
            this.shoppingCartBindingSource.DataSource = typeof(Main.ShoppingCart);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1028, 696);
            this.Controls.Add(this.name);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "재고관리 소프트웨어";
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1ProductImage)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.DataBase.ResumeLayout(false);
            this.DataBase.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chart1MyProduct)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.List.ResumeLayout(false);
            this.List.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productBindingSource)).EndInit();
            this.name.ResumeLayout(false);
            this.tapPage7.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.productBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.shoppingCartBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.shoppingCartBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

		#endregion

		private System.Windows.Forms.TabPage tabPage6;
		private System.Windows.Forms.Button button7;
		private System.Windows.Forms.TextBox textBox8;
		private System.Windows.Forms.DataGridView dataGridView2;
		private System.Windows.Forms.TabPage tabPage5;
		private System.Windows.Forms.Button button3;
		private System.Windows.Forms.Button button5;
		private System.Windows.Forms.Button button6;
		private System.Windows.Forms.GroupBox groupBox3;
		private System.Windows.Forms.TextBox textBox7;
		private System.Windows.Forms.GroupBox groupBox4;
		private System.Windows.Forms.PictureBox pictureBox2;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.TabPage tabPage4;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.TextBox textBox6;
		private System.Windows.Forms.TextBox textBox5;
		private System.Windows.Forms.TextBox textBox4;
		private System.Windows.Forms.TextBox textBox3;
		private System.Windows.Forms.TextBox textBox2;
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.DataGridView dataGridView1;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.TabPage tabPage3;
		private System.Windows.Forms.Label label7ShowProductPriceNaver;
		private System.Windows.Forms.Button SearchProductButton1;
		private System.Windows.Forms.TextBox textBox1SearchProduct;
		private System.Windows.Forms.Label label1ProductName;
		private System.Windows.Forms.PictureBox pictureBox1ProductImage;
		private System.Windows.Forms.TabPage tabPage2;
		private System.Windows.Forms.GroupBox DataBase;
		private System.Windows.Forms.Label CountMyProductNum;
		private System.Windows.Forms.Label CountMyProductTable;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.DataVisualization.Charting.Chart chart1MyProduct;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.Button buttonLarge;
		private System.Windows.Forms.Button buttonSmall;
		private System.Windows.Forms.Button buttonMiddle;
		private System.Windows.Forms.Button button4;
		private System.Windows.Forms.ComboBox comboBoxSmall;
		private System.Windows.Forms.ComboBox comboBoxLarge;
		private System.Windows.Forms.Label labelSmall;
		private System.Windows.Forms.Label labelLarge;
		private System.Windows.Forms.Label labelMiddle;
		private System.Windows.Forms.ComboBox comboBoxMIddle;
		private System.Windows.Forms.TabPage tabPage1;
		private System.Windows.Forms.TabControl name;
		private System.Windows.Forms.TabPage tapPage7;
		private System.Windows.Forms.GroupBox groupBox7;
		private System.Windows.Forms.GroupBox groupBox6;
		private System.Windows.Forms.GroupBox groupBox5;
		private System.Windows.Forms.Label pay_label;
		private System.Windows.Forms.Label count_label;
		private System.Windows.Forms.Label item_label;
		private System.Windows.Forms.Label pay;
		private System.Windows.Forms.Label count;
		private System.Windows.Forms.Label item;
		private System.Windows.Forms.TextBox barcd;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Button delete;
		private System.Windows.Forms.Button add;
		private System.Windows.Forms.Button search;
		private System.Windows.Forms.DataGridView dataGridView3;
		private System.Windows.Forms.BindingSource shoppingCartBindingSource;
		private System.Windows.Forms.DataGridViewTextBoxColumn barcodeDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn itemDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn countDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn payDataGridViewTextBoxColumn;
		private System.Windows.Forms.BindingSource shoppingCartBindingSource1;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Label position_Label;
        private System.Windows.Forms.Label position_O;
        private System.Windows.Forms.Label sale_Label;
        private System.Windows.Forms.TextBox sale_T;
        private System.Windows.Forms.Label sale;
        private System.Windows.Forms.TextBox purchase_T;
        private System.Windows.Forms.Label purchase_Label;
        private System.Windows.Forms.TextBox count_T;
        private System.Windows.Forms.Label purchase;
        private System.Windows.Forms.Label sale_TT;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label purchase_TT;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label count_TT;
        private System.Windows.Forms.Button Out;
        private System.Windows.Forms.TextBox position_T;
        private System.Windows.Forms.TextBox Barcd_F_T;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button Find;
        private System.Windows.Forms.Label position;
        private System.Windows.Forms.Label barcd_F;
        private System.Windows.Forms.Label barcd_Label;
        private System.Windows.Forms.Label div_n_Label;
        private System.Windows.Forms.Label div_m_Label;
        private System.Windows.Forms.Label img_prod_nm_Label;
        private System.Windows.Forms.Label item_no_Label;
        private System.Windows.Forms.Label nutrition_info_Label;
        private System.Windows.Forms.Label volume_Label;
        private System.Windows.Forms.Label comp_nm_Label;
        private System.Windows.Forms.Label div_s_Label;
        private System.Windows.Forms.Label div_l_Label;
        private System.Windows.Forms.Label item_cd_Label;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label nutrition_info;
        private System.Windows.Forms.Label volume;
        private System.Windows.Forms.Label img_prod_nm;
        private System.Windows.Forms.Label comp_nm;
        private System.Windows.Forms.Label div_n;
        private System.Windows.Forms.Label div_s;
        private System.Windows.Forms.Label div_m;
        private System.Windows.Forms.Label item_cd;
        private System.Windows.Forms.Label div_l;
        private System.Windows.Forms.Label item_no;
        private System.Windows.Forms.GroupBox List;
        private System.Windows.Forms.DataGridView dataGridView4;
        private System.Windows.Forms.BindingSource productBindingSource;
        private System.Windows.Forms.Label Timer;
        private System.Windows.Forms.Label Time;
        private System.Windows.Forms.ListBox Log;
        private System.Windows.Forms.Timer Timer1;
        private System.Windows.Forms.BindingSource productBindingSource1;
        private System.Windows.Forms.DataGridViewTextBoxColumn itemcdDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn itemnoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn divlDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn divmDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn divsDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn divnDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn compnmDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn imgprodnmDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn volumeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn barcdDV;
        private System.Windows.Forms.DataGridViewTextBoxColumn widthDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lengthDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nutritioninfoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn positionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn countDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn purchaseDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn saleDataGridViewTextBoxColumn;
    }
}

