﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security;
using System.Text;
using System.Threading.Tasks;

namespace CsharpProject
{
    public class UserInfo
    {
        public UserInfo()
        {
           
        }
        public static string DBName = "project";
        public static string Tablename = "sensor";
    }
}
